## References
- [Main paper citation]
- [Hydra]
- [SayPlan]
- [ESC]
- [Any other key works]
